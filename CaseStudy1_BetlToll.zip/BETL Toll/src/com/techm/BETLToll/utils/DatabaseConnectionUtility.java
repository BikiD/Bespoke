package com.techm.BETLToll.utils;

import java.sql.*;
public class DatabaseConnectionUtility {
public static Connection getConnection(){
    Connection con=null;
    try{
        Class.forName("oracle.jdbc.driver.OracleDriver");
        con=DriverManager.getConnection("jdbc:oracle:thin:@hstslc015:1521:elp","elp1737","msat123$");
        if(con!=null){
        System.out.println("true");
        }
    }
            catch(ClassNotFoundException f){
                f.printStackTrace();
            }
        catch(SQLException e){
            e.printStackTrace();
        }
    	return con;
}
public static Connection closeConnection(Connection con){
    
    try{
        con.close();
    }
   
        catch(SQLException e){
            e.printStackTrace();
        }
    	return con;
	}
    public static void main(String[] args) {
        DatabaseConnectionUtility.getConnection();
    }
}
