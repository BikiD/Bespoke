package com.techm.BETLToll.beans;
import java.io.Serializable;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
public class Passes implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String dateOfPass;
	private String fullName;
	private String vehicleNo;
	private String vehicleType;
	private String typeOfPass;
	private String dob;
    private String address;
    private String licenseNo;
    private String bloodGroup;
    private String validDate;
    
    
	public Passes() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Passes(String fullName, String vehicleNo, String vehicleType,
			String typeOfPass,String dob, String address, String licenseNo, String bloodGroup, String dateOfPass, String validDate) {
		super();
		this.fullName = fullName;
		this.vehicleNo = vehicleNo;
		this.typeOfPass = typeOfPass;
		this.address = address;
		this.vehicleType = vehicleType;
		this.dob=dob;
		this.licenseNo=licenseNo;
		this.bloodGroup=bloodGroup;
		this.dateOfPass=dateOfPass;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public String getVehicleNo() {
		return vehicleNo;
	}
	public void setVehicleNo(String vehicleNo) {
		this.vehicleNo = vehicleNo;
	}
	public String getTypeOfPass() {
		return typeOfPass;
	}
	public void setTypeOfPass(String typeOfPass) {
		this.typeOfPass = typeOfPass;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getVehicleType() {
		return vehicleType;
	}
	public void setVehicleType(String vehicleType) {
		this.vehicleType = vehicleType;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getLicenseNo() {
		return licenseNo;
	}
	public void setLicenseNo(String licenseNo) {
		this.licenseNo = licenseNo;
	}
	public String getBloodGroup() {
		return bloodGroup;
	}
	public void setBloodGroup(String bloodGroup) {
		this.bloodGroup = bloodGroup;
	}
	public String getDateOfPass() {
		return dateOfPass;
	}
	public void setDateOfPass(String dateOfPass) {
		this.dateOfPass = dateOfPass;
	}
	
	
	
	
	public String getValidDate() {
		return validDate;
	}
	public void setValidDate(String validDate) {
		this.validDate = validDate;
	}




	static int abc = 12345;
	public String genKey(){
		int key = abc + 123;
		abc=abc+123;
		String append = String.valueOf(key);
		String a= getDateOfPass().substring(8,10)+getDateOfPass().substring(5,7)+getVehicleType().substring(0,1)+append;
		return a;
	}
	public String dateIncrement1() throws ParseException{
		String dt = getDateOfPass();  // Start date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(dt));
		c.add(Calendar.DATE,1);  // number of days to add
		dt = sdf.format(c.getTime());
		return (dt);
	}
	public String dateIncrement30() throws ParseException{
		String dt = getDateOfPass();  // Start date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(dt));
		c.add(Calendar.DATE,30);  // number of days to add
		dt = sdf.format(c.getTime());
		return (dt);
	}
	public String dateIncrementRenew30() throws ParseException{
		String dt = getValidDate();  // Start date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		Calendar c = Calendar.getInstance();
		c.setTime(sdf.parse(dt));
		c.add(Calendar.DATE,30);  // number of days to add
		dt = sdf.format(c.getTime());
		return (dt);
	}
}
