package com.techm.BETLToll.beans;
import java.io.Serializable;

public class ExistingUserLogin implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String password;
	private String vehicleNo;
   
    public ExistingUserLogin(){
            super();
    }
    
    public ExistingUserLogin(String vehicleNo,String password){
        this.vehicleNo=vehicleNo;
        this.password=password;
    }
        
    public String getVehicleNo() {
	return vehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
	this.vehicleNo =vehicleNo;
    }

    public String getPassword() {
	return password;
    }

    public void setPassword(String password) {
        this. password = password;
    }


}