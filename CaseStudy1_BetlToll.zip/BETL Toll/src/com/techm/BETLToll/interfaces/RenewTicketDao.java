package com.techm.BETLToll.interfaces;

import java.text.ParseException;
import java.sql.SQLException;
import com.techm.BETLToll.beans.Passes;

public interface RenewTicketDao {
			
	public abstract int setRenewTicket(Passes ct)  throws ClassNotFoundException, SQLException, ParseException;
}