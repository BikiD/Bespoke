package com.techm.BETLToll.interfaces;

import java.sql.SQLException;

import com.techm.BETLToll.beans.*;

public interface ExistingUserLoginDao {

	public abstract boolean validateUser(ExistingUserLogin login ) throws ClassNotFoundException, SQLException;
	

}

