package com.techm.BETLToll.interfaces;
import com.techm.BETLToll.beans.Passes;

import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;


public interface PassesDao {
    public abstract List<?> getPassesDetails(Passes c ) throws ClassNotFoundException, SQLException;
    public abstract String setPassesDetails(Passes c)  throws ClassNotFoundException, SQLException, ParseException;

}