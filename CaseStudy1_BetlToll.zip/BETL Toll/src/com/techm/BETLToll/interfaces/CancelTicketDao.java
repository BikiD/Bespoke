package com.techm.BETLToll.interfaces;

import java.sql.SQLException;
import com.techm.BETLToll.beans.ExistingUserLogin;

	public interface CancelTicketDao {
		
	    public abstract int setCancelTicket(ExistingUserLogin ct)  throws ClassNotFoundException, SQLException;

}
