package com.techm.BETLToll.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.service.CancelTicketService;

public class CancelTicketController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public CancelTicketController() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		try {
			HttpSession session= request.getSession();
			PrintWriter out = response.getWriter();
			if (session != null) {

				String vehicleNo = request.getParameter("vehicleNo");

				System.out.println("got parameters");
				System.out.println("in CancelTicket controller...." + vehicleNo);

				ExistingUserLogin ct = new ExistingUserLogin();

				ct.setVehicleNo(vehicleNo);

				System.out.println("set parameters");

				// CancelTicketService cs=new CancelTicketService();

				int x;
				x = CancelTicketService.setCancelTicket(ct);
				System.out.println("X = " + x);

				if (x > 0) {

					// rd.include(request, response);

					out.println(
							"<html><body><center><h1>Bangalore Elevated Tollway Limited</h1><h3>!Ticket Cancelled!</h3><h2>We are making arrangements to refund you your payment.</h3><h4>Thank you for being a part of BETL Automated Toll.</h4></center></body></html>");
					// request.setAttribute(arg0, arg1)
					// rd = request.getRequestDispatcher("/cancelled.html");
					// rd.forward(request, response);}
				}
			}
			else{
				response.sendRedirect("BETL Toll Existing Login.jsp");
			}
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
