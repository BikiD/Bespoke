package com.techm.BETLToll.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.daoimplementation.ExistingUserLoginDaoImplementations;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;

public class GetExistingUserDetailsController extends HttpServlet {
		private static final long serialVersionUID = 1L;
	    
	    public GetExistingUserDetailsController() {
	        super();
	        }
	    
		protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			// TODO Auto-generated method stub
			HttpSession session = request.getSession();
			if(session==null){
				response.sendRedirect("BETL Toll Existing Login.jsp");
			}
			
			
		}

		
			protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				// TODO Auto-generated method stub
				
				String vehicleNo = request.getParameter("vehicleNo");
				String password=request.getParameter("password");
		        //System.out.println(userName);
		        ExistingUserLogin loginInfo = new ExistingUserLogin();
		        loginInfo.setVehicleNo(vehicleNo);
		        loginInfo.setPassword(password);
		      
		        System.out.println("in Get ExistingUserLogin controller....");
		        
		        
				
				
				PrintWriter out= response.getWriter();
				
		        
		        ExistingUserLoginDaoImplementations login = new ExistingUserLoginDaoImplementations();
		        
		   
		        
		       
		       
		        
		        try {
		        	Connection con = DatabaseConnectionUtility.getConnection();
			        
			        Statement stmt = con.createStatement();
			        
			        String query = "select * from BETL_TOLL_BS where vehicle_number like '"+vehicleNo+"'";
			        
			        ResultSet rs = stmt.executeQuery(query);
			        
					if( login.validateUser(loginInfo))
					{
						HttpSession session = request.getSession();
						session.setAttribute("VehicleNo", vehicleNo);
						
						while(rs.next())
						{
						request.setAttribute("value1", rs.getString(1));
						request.setAttribute("value2", rs.getString(2));
						request.setAttribute("value3", rs.getString(3));
						request.setAttribute("value4", rs.getString(4));
						request.setAttribute("value5", rs.getString(5));
						request.setAttribute("value6", rs.getString(6));
						request.setAttribute("value7", rs.getString(7));
						request.setAttribute("value8", rs.getString(8));
						request.setAttribute("value9", rs.getString(9));
						request.setAttribute("value10", rs.getString(10));
						request.setAttribute("value11", rs.getString(11));
						
					    RequestDispatcher rd1 = request.getRequestDispatcher("displaynewuser1.jsp");
					    rd1.forward(request, response);
						}

					}

					
				else {
					out.println("<html><body><center><h1>Bangalore Elevated Tollway Limited</h1><h3>invalid username and password</center></h3></body></html>");          
					  
					    

					}
				} catch (ClassNotFoundException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				
				
		}

	}
