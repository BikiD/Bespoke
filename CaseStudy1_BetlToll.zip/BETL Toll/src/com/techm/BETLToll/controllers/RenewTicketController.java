package com.techm.BETLToll.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.ParseException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techm.BETLToll.beans.Passes;
import com.techm.BETLToll.service.RenewTicketService;


public class RenewTicketController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    public RenewTicketController() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		try
		{
			String vno=request.getParameter("vno");
			String vdate=request.getParameter("vd");
			HttpSession session= request.getSession();
			PrintWriter out = response.getWriter();
			if (session != null) 
			{
		//PrintWriter out= response.getWriter();
		
		
	//	String validDate=request.getParameter("validDate");
		
			System.out.println("got parameters");
		//	System.out.println("in RenewTicket controller...."+validDate);

           
			/*Connection connection=DatabaseConnectionUtility.getConnection();
			PreparedStatement pstmt=connection.prepareStatement("SELECT VALID_DATE FROM REGISTRATION_USER WHERE VEHICLE_NUMBER='"+vno+"'");
			ResultSet rs=pstmt.executeQuery();
			String validDate;
			if(rs.next()){
				validDate=rs.getString(1);
			}*/
		Passes ct=new Passes();
		
		ct.setVehicleNo(vno);
		ct.setValidDate(vdate);
		
		System.out.println("set parameters");
		
		
		int x;
		x = RenewTicketService.setRenewTicket(ct);
		System.out.println("X = "+x);
		
		if(x>0)
		 {			 
	        
	       // rd.include(request, response);
	        
		 out.println("<html><body><center><h1>Bangalore Elevated Tollway Limited</h1><h3>Ticket Renewed</h3></center></body></html>");
		 //request.setAttribute(arg0, arg1)
		 //RequestDispatcher rd = request.getRequestDispatcher("displaynewuser1.jsp");
	   //  rd.forward(request, response);}
		 }
		}
		}
		catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		}
	}
}



