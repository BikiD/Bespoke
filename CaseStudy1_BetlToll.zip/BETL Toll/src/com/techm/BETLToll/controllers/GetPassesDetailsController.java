package com.techm.BETLToll.controllers;
import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.beans.Passes;
import com.techm.BETLToll.service.PassesService;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.List;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class GetPassesDetailsController extends HttpServlet {
   
   
   
 /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

@SuppressWarnings({ "unused", "rawtypes" })
public void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException {
 
      
       RequestDispatcher rd=request.getRequestDispatcher("displaynewuser.jsp");
       String customerName= request.getParameter("fullName");
       String address=request.getParameter("address");
       String BloodGroup=request.getParameter("bloodGroup");
       String DOB=request.getParameter("dob");
       String vehicleNumber=request.getParameter("vehicleNo");
       String licenseNumber=request.getParameter("licenseNo");
       String vehicleType=request.getParameter("vehicleType");
       String typeofpass=request.getParameter("typeOfPass");
       String dateofpass=request.getParameter("dateOfPass");
       String vehicleNo = request.getParameter("vehicleNo");
       
       ExistingUserLogin loginInfo = new ExistingUserLogin();
       loginInfo.setVehicleNo(vehicleNo);
       
       Passes c=new Passes();
       c.setFullName(customerName);
       c.setAddress(address);
       c.setBloodGroup(BloodGroup);
       c.setDob(DOB);
       c.setVehicleNo(vehicleNumber);
       c.setLicenseNo(licenseNumber);
       c.setVehicleType(vehicleType);
       c.setTypeOfPass(typeofpass);
       c.setDateOfPass(dateofpass);
      
       System.out.println("in Get PassesDetails controller...."); 
       
       PassesService cs = new PassesService();
      String status="";
      
      
      List PassesList=null;
       try {
    	   
    	   HttpSession session= request.getSession();
			PrintWriter out = response.getWriter();
			if (session != null) {
				
    	   status = cs.setPassesDetails(c);
    	   PassesList=cs.getPassesDetails(c);
    	   Connection con = DatabaseConnectionUtility.getConnection();
    	   Statement stmt = con.createStatement();
	       String query = "select * from BETL_TOLL_BS where vehicle_number like '"+vehicleNo+"'";
    	   ResultSet rs = stmt.executeQuery(query);
    	   while(rs.next())
    	   {
    		   request.setAttribute("value9", rs.getString(9));
    		   request.setAttribute("value11",rs.getString(11));
    	   }
		
		
		request.setAttribute("NewUser", c);
		rd.forward(request, response);
			}
       } catch (SQLException e) {
		e.printStackTrace();
       }catch(ClassNotFoundException ce){
            ce.printStackTrace();
       } catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
        
    } 

  
}