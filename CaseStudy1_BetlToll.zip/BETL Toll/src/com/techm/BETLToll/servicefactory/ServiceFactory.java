package com.techm.BETLToll.servicefactory;

import com.techm.BETLToll.service.PassesService;
import com.techm.BETLToll.service.RenewTicketService;
import com.techm.BETLToll.service.CancelTicketService;
import com.techm.BETLToll.service.ExistingUserLoginService;

public class ServiceFactory {
	
	 private static PassesService passesservice=null;

	 public static PassesService getCustomerService(){
			 
			 if(passesservice==null){
				 passesservice=new PassesService();
			 }
			 else
			 {
				 return passesservice;
			 }
		        return passesservice;
		 }
	 private static ExistingUserLoginService loginService=null;

	 public static ExistingUserLoginService getLoginService( ){
		 
	     if(loginService==null){
	         loginService= new ExistingUserLoginService( );
	     }
	     else
	     {
	         return loginService;
	     }
	     return loginService;
	 }
	 private static CancelTicketService CancelTktService=null;

	 public static CancelTicketService getCancelTicketService( ){
		 
	     if(CancelTktService==null){
	         CancelTktService= new CancelTicketService( );
	     }
	     else
	     {
	         return CancelTktService;
	     }
	     return CancelTktService;
	 }
	 private static RenewTicketService RenewTktService=null;
	 
	 public static RenewTicketService getRenewTicketService( ){
		 
	     if(RenewTktService==null){
	         RenewTktService= new RenewTicketService( );
	     }
	     else
	     {
	         return RenewTktService;
	     }
	     return RenewTktService;
	 }

}
