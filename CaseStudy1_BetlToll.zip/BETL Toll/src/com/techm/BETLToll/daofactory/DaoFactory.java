package com.techm.BETLToll.daofactory;

import com.techm.BETLToll.daoimplementation.PassesDaoImplemetations;
import com.techm.BETLToll.daoimplementation.RenewTicketDaoImplementations;
import com.techm.BETLToll.daoimplementation.CancelTicketDaoImplementation;
import com.techm.BETLToll.daoimplementation.ExistingUserLoginDaoImplementations;
import com.techm.BETLToll.interfaces.CancelTicketDao;
import com.techm.BETLToll.interfaces.ExistingUserLoginDao;
import com.techm.BETLToll.interfaces.PassesDao;
import com.techm.BETLToll.interfaces.RenewTicketDao;

	public class DaoFactory {
	private static PassesDao passesdao=null;
		
		public static PassesDao getCustomerDao(){
	        if(passesdao==null){
	           passesdao=new PassesDaoImplemetations();
	        }
	        else{
	            return passesdao;
	        }
	        return passesdao;

		}
		
			
			private static ExistingUserLoginDao loginDao=null;
			
			
			public static ExistingUserLoginDao getLoginDao(){
		        if(loginDao==null){
		            loginDao=new ExistingUserLoginDaoImplementations();
		        }
		        else{
		            return loginDao;
		        }
		        return loginDao;
			
			}
			private static CancelTicketDao cncltktDao=null;
			
			
			public static CancelTicketDao cncltkt(){
		        if(cncltktDao==null){
		            cncltktDao=new CancelTicketDaoImplementation();
		        }
		        else{
		            return cncltktDao;
		        }
		        return cncltktDao;
			
			}
			private static RenewTicketDao renewtktDao=null;
			
			
			public static RenewTicketDao renewtkt(){
		        if(renewtktDao==null){
		            renewtktDao=new RenewTicketDaoImplementations();
		        }
		        else{
		            return renewtktDao;
		        }
		        return renewtktDao;
			
			}
			
}
