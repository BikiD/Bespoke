package com.techm.BETLToll.service;

import com.techm.BETLToll.beans.Passes;
import com.techm.BETLToll.daoimplementation.PassesDaoImplemetations;
import com.techm.BETLToll.interfaces.PassesDao;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.List;


public class PassesService {

    public List<?> getPassesDetails(Passes c ) throws ClassNotFoundException, SQLException{
        PassesDao passesDao =new PassesDaoImplemetations();
        return passesDao.getPassesDetails(c);
    }
    public String setPassesDetails(Passes c) throws ClassNotFoundException, SQLException, ParseException{
    	   System.out.println("Inside Passes service class..."); 
        PassesDao passesDao =new PassesDaoImplemetations();
         return passesDao.setPassesDetails(c);
    }
   
}
