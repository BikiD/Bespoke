package com.techm.BETLToll.service;

import java.sql.SQLException;
import java.text.ParseException;

import com.techm.BETLToll.daoimplementation.RenewTicketDaoImplementations;
import com.techm.BETLToll.interfaces.RenewTicketDao;
import com.techm.BETLToll.beans.Passes;


public class RenewTicketService {

	
    
    public static int setRenewTicket(Passes ct) throws ClassNotFoundException, SQLException, ParseException{
    	 RenewTicketDao renewTicketDao =  new RenewTicketDaoImplementations();
         System.out.println("welcome");
    	 return renewTicketDao.setRenewTicket(ct);
    }
	
}
