package com.techm.BETLToll.service;

import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.daofactory.DaoFactory;
import com.techm.BETLToll.interfaces.ExistingUserLoginDao;
import java.sql.SQLException;

public class ExistingUserLoginService {
public boolean validateUser(ExistingUserLogin loginInfo) throws ClassNotFoundException, SQLException
{
        
		ExistingUserLoginDao loginDao = DaoFactory.getLoginDao();
        
        return loginDao.validateUser(loginInfo);
    }

}
