package com.techm.BETLToll.service;

import java.sql.SQLException;
import com.techm.BETLToll.daoimplementation.CancelTicketDaoImplementation;
import com.techm.BETLToll.interfaces.CancelTicketDao;
import com.techm.BETLToll.beans.ExistingUserLogin;


public class CancelTicketService {

	
    
    public static int setCancelTicket(ExistingUserLogin ct) throws ClassNotFoundException, SQLException{
    	 CancelTicketDao cancelTicketDao =(CancelTicketDao) new CancelTicketDaoImplementation();
         System.out.println("welcome");
    	 return cancelTicketDao.setCancelTicket(ct);
    }
	
}
