package com.techm.BETLToll.daoimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;

import com.techm.BETLToll.interfaces.RenewTicketDao;
import com.techm.BETLToll.beans.Passes;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;

public class RenewTicketDaoImplementations implements RenewTicketDao {
		

public int setRenewTicket (Passes c) throws ClassNotFoundException,SQLException, ParseException{
			
		
	Connection connection=DatabaseConnectionUtility.getConnection();
	int message;
	PreparedStatement pstmt=connection.prepareStatement("UPDATE BETL_TOLL_BS SET VALID_DATE=? WHERE VEHICLE_NUMBER=?");
			String nd=c.dateIncrementRenew30();
	pstmt.setString(1,nd);
	pstmt.setString(2,c.getVehicleNo());
	System.out.println("Valid Date updated");
	
	message=pstmt.executeUpdate();
	DatabaseConnectionUtility.closeConnection(connection);
	System.out.println("updated");
	return message;
	}
}

