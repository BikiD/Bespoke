package com.techm.BETLToll.daoimplementation;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import com.techm.BETLToll.interfaces.CancelTicketDao;
import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;

public class CancelTicketDaoImplementation implements CancelTicketDao {
		

public int setCancelTicket (ExistingUserLogin ct) throws ClassNotFoundException,SQLException{
			
		
	Connection connection=DatabaseConnectionUtility.getConnection();
	int message;
	PreparedStatement pstmt=connection.prepareStatement("delete from BETL_TOLL_BS where VEHICLE_NUMBER=?");
				
	pstmt.setString(1, ct.getVehicleNo());
	System.out.println("vehicle number executed");
	
	message=pstmt.executeUpdate();
	DatabaseConnectionUtility.closeConnection(connection);
	System.out.println("executed");
	return message;
	}
}

