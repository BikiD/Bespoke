package com.techm.BETLToll.daoimplementation;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.techm.BETLToll.interfaces.ExistingUserLoginDao;
import com.techm.BETLToll.beans.ExistingUserLogin;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;

public class ExistingUserLoginDaoImplementations implements ExistingUserLoginDao {
	Connection con=null;
	
	public boolean validateUser(ExistingUserLogin loginInfo) throws ClassNotFoundException,
			SQLException {
		// TODO Auto-generated method stub
        
        
        boolean res;
         Connection con=DatabaseConnectionUtility.getConnection();
        
        
        Statement psmt = con.createStatement();
        String sql="select vehicle_number,ticket_number from BETL_TOLL_BS where vehicle_number='"+loginInfo.getVehicleNo()+"' and ticket_number='"+loginInfo.getPassword()+"'";
        System.out.println(loginInfo.getVehicleNo()+"  "+loginInfo.getPassword());
        ResultSet rs = psmt.executeQuery(sql);
        if(rs.next()==false)
        {
        	res=false;
        }
        else
        {
        	res=true;
        }
        return res;
       
       }


}