package com.techm.BETLToll.daoimplementation;
import com.techm.BETLToll.beans.Passes;
import com.techm.BETLToll.interfaces.PassesDao;
import com.techm.BETLToll.utils.DatabaseConnectionUtility;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

	public class PassesDaoImplemetations  implements PassesDao{
	    Connection con = null;

	    public List<Passes> getPassesDetails(Passes c )throws ClassNotFoundException, SQLException{
	        List<Passes> passesList = new ArrayList<Passes>( );
	        Connection con = DatabaseConnectionUtility.getConnection();
	        Statement stmt = con.createStatement();
	        ResultSet rs = stmt.executeQuery("select * from BETL_TOLL_BS");
	       Passes passes = new Passes();
	         while(rs.next()){
	            passes.setVehicleNo(rs.getString(1));
	            passes.setFullName(rs.getString(2));
	            passes.setLicenseNo(rs.getString(3));
	            passes.setDob(rs.getString(4));
	            passes.setTypeOfPass(rs.getString(5));
	            passes.setBloodGroup(rs.getString(6));
	            passes.setAddress(rs.getString(7));
	            passes.setVehicleType(rs.getString(8));
	            passes.setDateOfPass(rs.getString(9));


	            passesList.add(passes);

	        }

	        return passesList;
	    }

	    public  String setPassesDetails (Passes c) throws ClassNotFoundException, SQLException, ParseException{
	    	System.out.println("Before connection Inside passes DOA class");
	    	
	        System.out.println("Inside passes DOA class");
		  String message=null;
	        Connection con=DatabaseConnectionUtility.getConnection();
	          PreparedStatement pstmt = con.prepareStatement("insert into BETL_TOLL_BS (vehicle_number,fullname,license_number,dob,type_of_pass,blood_group,address,type_of_vehicle,ticket_number,date_of_pass,valid_date)values(?,?,?,?,?,?,?,?,?,?,?)");
	          pstmt.setString(1,c.getVehicleNo()); 
	          pstmt.setString(2,c.getFullName());
	          pstmt.setString(3,c.getLicenseNo());
	          pstmt.setString(4,c.getDob());
	          pstmt.setString(5,c.getTypeOfPass());
	          pstmt.setString(6,c.getBloodGroup());
	          pstmt.setString(7,c.getAddress());
	          pstmt.setString(8,c.getVehicleType());
	          pstmt.setString(9,c.genKey());
	          pstmt.setString(10,c.getDateOfPass());
	          
	          if(c.getTypeOfPass().equals("One Day"))
	        		pstmt.setString(11,c.dateIncrement1());
	          else if(c.getTypeOfPass().equals("Monthly"))
	        	  	pstmt.setString(11,c.dateIncrement30());

	          //pstmt.executeQuery();
	          pstmt.executeUpdate();
	           message="success";
	           
	           System.out.println(message);
	     
	         DatabaseConnectionUtility.closeConnection(con);
	   return message;
	   }
}
